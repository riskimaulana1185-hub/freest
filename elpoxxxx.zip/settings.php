<?php
$url = "https://beck-end3.my.id/sunil/"; // Ganti dengan endpoint anda
?>