<?php

$namagrp = '🔞GIRL HIJAB PRIVATE MALAYSIA 🔞'; //Nama Grup/Channel Telegram

$fotogrp = '/bengke.png'; //Foto Grup/Channel Telegram

$subs = '23 111 members, 12 934 online'; //Jumlah subscribe Channel/grup Telegram

?>